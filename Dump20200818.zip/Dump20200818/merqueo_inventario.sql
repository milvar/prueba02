-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: merqueo
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario` (
  `idinventario` bigint(20) NOT NULL AUTO_INCREMENT,
  `idarticulos` bigint(20) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `precio` decimal(10,0) NOT NULL,
  `ciudad` int(11) NOT NULL,
  `estado` bit(1) NOT NULL,
  PRIMARY KEY (`idinventario`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES (1,1,140,3000,10,_binary ''),(2,1,290,3000,11,_binary ''),(3,2,244,12000,11,_binary ''),(4,2,344,12000,10,_binary ''),(5,3,60,1200,10,_binary ''),(6,3,60,1200,11,_binary ''),(7,4,498,8000,10,_binary ''),(8,4,408,8000,11,_binary ''),(9,5,200,2000,10,_binary ''),(10,5,150,2000,11,_binary ''),(11,6,100,10000,10,_binary ''),(12,6,80,10000,11,_binary ''),(13,7,196,9000,10,_binary ''),(14,7,216,9000,11,_binary ''),(15,8,80,12000,10,_binary ''),(16,8,55,12000,11,_binary ''),(17,9,40,44000,10,_binary ''),(18,9,25,44000,11,_binary ''),(19,10,45,38000,10,_binary ''),(20,10,35,38000,11,_binary ''),(21,11,200,6000,10,_binary ''),(22,11,130,6000,11,_binary ''),(23,12,180,7000,10,_binary ''),(24,12,130,7000,11,_binary ''),(31,23,100,5000,10,_binary ''),(32,24,100,5000,11,_binary ''),(33,25,100,5000,10,_binary ''),(34,26,100,5000,11,_binary '');
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-18  1:49:47
