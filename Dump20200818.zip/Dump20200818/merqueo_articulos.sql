-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: merqueo
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulos` (
  `idarticulos` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcategoria_productos` bigint(20) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` varchar(90) NOT NULL,
  `codigobarras` varchar(45) NOT NULL,
  `estado` bit(1) NOT NULL,
  PRIMARY KEY (`idarticulos`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulos`
--

LOCK TABLES `articulos` WRITE;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` VALUES (1,1,'leche ','bolsas de leche','789456321',_binary ''),(2,4,'salchichon ','bara de salchichon cervecero','789456321',_binary ''),(3,1,'yogurt','yogurt ','748599663',_binary ''),(4,1,'queso doble crema','quesos nacionales ','741236985',_binary ''),(5,7,'Arroz por libras','arroz por libras','7458956',_binary ''),(6,7,'Arroz 3 kilos','arroz por 6 libras','74589856',_binary ''),(7,5,'huevos AA ','huevos x 30','742589631',_binary ''),(8,5,'huevos AAA ','huevos x 30','742589638',_binary ''),(9,6,'Aguardiente Cristal 750ml ','producto nacional','854796521',_binary ''),(10,6,'Aguardiente antioqueño 750ml ','producto nacional','854796558',_binary ''),(11,9,'pan tajado mantequilla ','pan tajado 300 gramos','758963255',_binary ''),(12,1,'mantequilla de vaca','mantequilla 300 gramos','965874235',_binary ''),(23,18,'ajo','paquete de 500gramos','74855965',_binary ''),(24,18,'ajo','paquete de 300gramos','74855985',_binary ''),(25,18,'pimienta','paquete de 300gramos','74855974',_binary ''),(26,18,'pimienta','paquete de 300gramos','74855933',_binary '');
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-18  1:49:48
