-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: merqueo
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido` (
  `idpedido` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcliente` bigint(20) NOT NULL,
  `token` varchar(60) NOT NULL,
  `iddireccion` bigint(20) NOT NULL,
  `direccion` varchar(90) NOT NULL,
  `ciudad` int(11) NOT NULL,
  `fechapedido` date NOT NULL,
  `fechaentrega` date NOT NULL,
  `estado` varchar(2) NOT NULL,
  PRIMARY KEY (`idpedido`),
  UNIQUE KEY `token_UNIQUE` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
INSERT INTO `pedido` VALUES (1,1,'12345678',1,'nort oeste',10,'2020-08-14','2020-08-15','p'),(2,2,'12345679',1,'nort oeste',11,'2020-08-14','2020-08-15','p'),(3,3,'12345680',1,'nort oeste',10,'2020-08-14','2020-08-15','p'),(4,4,'12345681',1,'sur oeste',11,'2020-08-14','2020-08-15','p'),(5,1,'1000010',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(6,2,'1000011',1,'nort oeste',11,'2020-08-17','2020-08-18','p'),(7,3,'1000012',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(8,4,'1000013',1,'sur oeste',11,'2020-08-17','2020-08-18','p'),(13,1,'1000020',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(14,2,'1000021',1,'nort oeste',11,'2020-08-17','2020-08-18','p'),(15,3,'1000022',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(16,4,'1000023',1,'sur oeste',11,'2020-08-17','2020-08-18','p'),(17,1,'1000030',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(18,2,'1000031',1,'nort oeste',11,'2020-08-17','2020-08-18','p'),(19,3,'1000032',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(20,4,'1000033',1,'sur oeste',11,'2020-08-17','2020-08-18','p'),(21,1,'1000040',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(22,2,'1000041',1,'nort oeste',11,'2020-08-17','2020-08-18','p'),(23,3,'1000042',1,'nort oeste',10,'2020-08-17','2020-08-18','p'),(24,4,'1000043',1,'sur oeste',11,'2020-08-17','2020-08-18','p'),(29,1,'1000060',1,'nort oeste',10,'2020-08-18','2020-08-19','p'),(30,2,'1000061',1,'nort oeste',11,'2020-08-18','2020-08-19','p'),(31,3,'1000062',1,'nort oeste',10,'2020-08-18','2020-08-19','p'),(32,4,'1000063',1,'sur oeste',11,'2020-08-18','2020-08-19','p'),(33,1,'1000070',1,'nort oeste',10,'2020-08-18','2020-08-19','p'),(34,2,'1000071',1,'nort oeste',11,'2020-08-18','2020-08-19','p'),(35,3,'1000072',1,'nort oeste',10,'2020-08-18','2020-08-19','p'),(36,4,'1000073',1,'sur oeste',11,'2020-08-18','2020-08-19','p');
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-18  1:49:47
