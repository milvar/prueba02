-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: merqueo
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proveedor_ciudad`
--

DROP TABLE IF EXISTS `proveedor_ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_ciudad` (
  `idproveedor_ciudad` bigint(20) NOT NULL AUTO_INCREMENT,
  `idproveedor` bigint(20) NOT NULL,
  `ciudad` int(11) NOT NULL,
  `direccion` varchar(90) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `estado` bit(1) NOT NULL,
  PRIMARY KEY (`idproveedor_ciudad`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_ciudad`
--

LOCK TABLES `proveedor_ciudad` WRITE;
/*!40000 ALTER TABLE `proveedor_ciudad` DISABLE KEYS */;
INSERT INTO `proveedor_ciudad` VALUES (1,1,10,'calle 4 # 5 ','7485962',_binary ''),(2,1,11,'calle 4 # 5 ','7845858',_binary ''),(3,2,10,'calle 4 # 5 ','85969575',_binary ''),(4,3,10,'calle 4 # 5 ','85412369',_binary ''),(5,4,11,'calle 4 # 5 ','56321478',_binary ''),(6,5,10,'calle 4 # 5 ','9658742',_binary ''),(7,5,11,'calle 4 # 5 ','96587442',_binary ''),(8,6,10,'calle 4 # 5 ','325698745',_binary ''),(9,6,11,'calle 4 # 5 ','632589741',_binary ''),(10,7,10,'calle 4 # 5 ','965214789',_binary ''),(11,7,11,'calle 4 # 5 ','521478958',_binary ''),(12,8,10,'calle 4 # 5 ','320585965',_binary ''),(13,8,11,'calle 4 # 5 ','2145874036',_binary ''),(14,9,10,'calle 4 # 5 ','24585962',_binary ''),(27,30,10,'calle 12 # 15','7458562',_binary ''),(28,30,11,'calle 12 # 10','748589',_binary ''),(29,30,12,'calle 12 # 14','854796',_binary '');
/*!40000 ALTER TABLE `proveedor_ciudad` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-18  1:49:48
