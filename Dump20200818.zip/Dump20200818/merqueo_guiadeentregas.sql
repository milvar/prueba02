-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: merqueo
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `guiadeentregas`
--

DROP TABLE IF EXISTS `guiadeentregas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guiadeentregas` (
  `idguiadeentregas` int(11) NOT NULL AUTO_INCREMENT,
  `idpedido` bigint(20) NOT NULL,
  `fecha` date NOT NULL,
  `placavehiculo` varchar(10) NOT NULL,
  `estado` varchar(12) NOT NULL,
  PRIMARY KEY (`idguiadeentregas`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guiadeentregas`
--

LOCK TABLES `guiadeentregas` WRITE;
/*!40000 ALTER TABLE `guiadeentregas` DISABLE KEYS */;
INSERT INTO `guiadeentregas` VALUES (1,1,'2020-08-14','hgj456','envio'),(2,1,'2020-08-14','hgj456','envio'),(3,1,'2020-08-14','hgj456','envio'),(4,1,'2020-08-14','hgj456','envio'),(5,2,'2020-08-14','hgj456','envio'),(6,2,'2020-08-14','hgj456','envio'),(7,2,'2020-08-14','hgj456','envio'),(8,2,'2020-08-14','hgj456','envio'),(9,3,'2020-08-14','hgj456','envio'),(10,3,'2020-08-14','hgj456','envio'),(11,3,'2020-08-14','hgj456','envio'),(12,3,'2020-08-14','hgj456','envio'),(13,4,'2020-08-14','hgj456','envio'),(14,4,'2020-08-14','hgj456','envio'),(15,4,'2020-08-14','hgj456','envio'),(16,4,'2020-08-14','hgj456','envio'),(17,5,'2020-08-17','hgj456','envio'),(18,5,'2020-08-17','hgj456','envio'),(19,5,'2020-08-17','hgj456','envio'),(20,5,'2020-08-17','hgj456','envio'),(21,6,'2020-08-17','hgj456','envio'),(22,6,'2020-08-17','hgj456','envio'),(23,6,'2020-08-17','hgj456','envio'),(24,6,'2020-08-17','hgj456','envio'),(25,7,'2020-08-17','hgj456','envio'),(26,7,'2020-08-17','hgj456','envio'),(27,7,'2020-08-17','hgj456','envio'),(28,7,'2020-08-17','hgj456','envio'),(29,8,'2020-08-17','hgj456','envio'),(30,8,'2020-08-17','hgj456','envio'),(31,8,'2020-08-17','hgj456','envio'),(32,8,'2020-08-17','hgj456','envio'),(33,13,'2020-08-17','hgj456','envio'),(34,13,'2020-08-17','hgj456','envio'),(35,13,'2020-08-17','hgj456','envio'),(36,13,'2020-08-17','hgj456','envio'),(37,14,'2020-08-17','hgj456','envio'),(38,14,'2020-08-17','hgj456','envio'),(39,14,'2020-08-17','hgj456','envio'),(40,14,'2020-08-17','hgj456','envio'),(41,15,'2020-08-17','hgj456','envio'),(42,15,'2020-08-17','hgj456','envio'),(43,15,'2020-08-17','hgj456','envio'),(44,15,'2020-08-17','hgj456','envio'),(45,16,'2020-08-17','hgj456','envio'),(46,16,'2020-08-17','hgj456','envio'),(47,16,'2020-08-17','hgj456','envio'),(48,16,'2020-08-17','hgj456','envio'),(49,17,'2020-08-17','hgj456','envio'),(50,18,'2020-08-17','hgj456','envio'),(51,19,'2020-08-17','hgj456','envio'),(52,20,'2020-08-17','hgj456','envio'),(53,21,'2020-08-17','hgj456','envio'),(54,22,'2020-08-17','hgj456','envio'),(55,23,'2020-08-17','hgj456','envio'),(56,24,'2020-08-17','hgj456','envio'),(57,0,'2020-08-18','hgj456','envio'),(58,0,'2020-08-18','hgj456','envio'),(59,0,'2020-08-18','hgj456','envio'),(60,0,'2020-08-18','hgj456','envio'),(61,29,'2020-08-18','hgj456','envio'),(62,30,'2020-08-18','hgj456','envio'),(63,31,'2020-08-18','hgj456','envio'),(64,32,'2020-08-18','hgj456','envio'),(65,33,'2020-08-18','hgj456','envio'),(66,34,'2020-08-18','hgj456','envio'),(67,35,'2020-08-18','hgj456','envio'),(68,36,'2020-08-18','hgj456','envio');
/*!40000 ALTER TABLE `guiadeentregas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-18  1:49:48
